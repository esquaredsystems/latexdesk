This folder was created from the "elsevier-cas-sc" starter in the LaTeX Desk template library.
Build it with LaTeX Desk (Ctrl+Alt+B) or with latexmk. The document class comes from your TeX
distribution; check the publisher's author instructions for the current requirements.
